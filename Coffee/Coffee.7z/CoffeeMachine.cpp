#include "CoffeeMachine.h"
#include"CoffeeMachineRecipe.h"

CoffeeMachine::CoffeeMachine(int water, int sugar, int milk, int coffee):
	m_curWater(water),
	m_curSugar(sugar),
	m_curMilk(milk),
	m_curValCoffee(coffee)
{
	if (m_curWater <= m_minLevelWater || m_curValCoffee <= m_minValCoffee) {
		std::cout << "chek lvl of water and coffee";
	}	

}
bool CoffeeMachine::ChekIngredientLowLvl(int water, int sugar, int milk, int coffee) {
	bool res = true;
	if (m_curWater <= m_lowLevelWater) {
		std::cout << "Water low level" << std::endl;
		if (m_curWater - water <= m_minLevelWater) {
			std::cout << "Water min level, please add water" << std::endl;
			res = false;
		}
	}
	if (m_curSugar <= m_lowValSugar) {
		std::cout << "Sugar low level" << std::endl;
		if (m_curSugar - sugar <= m_minLevelWater) {
			std::cout << "Sugar min level, please add sugar, or make without." << std::endl;
			res = false;
		}
	}
	if (m_curMilk - milk <= m_minLevelmilk) {
		std::cout << "Milk min level, please add milk, or choose another drink" << std::endl;
		res = false;
	}
	if (m_curValCoffee - coffee <= m_minValCoffee) {
		std::cout << "Coffee min level, please add coffee please" << std::endl;
		res = false;
	}
	return res;
}
bool CoffeeMachine::MakeDrink(CoffeeMachineRecipe::recipe curRecipe) {
	bool res = ChekIngredientLowLvl(curRecipe.water, curRecipe.sugar, curRecipe.milk, curRecipe.coffee);
	if (res) {
	m_curWater -= curRecipe.water;
	m_curSugar -= curRecipe.sugar;
	m_curMilk -= curRecipe.milk;
	m_curValCoffee -= curRecipe.coffee;
	}
	return res;
}
int Add(int add, int& cur, int max) {
	int res = 0;
	if ((cur += add) > max) {
		res = (cur - max);
		cur = max;
	}
	return res;
}
int CoffeeMachine::AddWater(int add) {
	int res = Add(add, m_curWater, m_maxLevelWater);
	return res;
}
int CoffeeMachine::AddSugar(int add) {
	int res = Add(add, m_curSugar, m_maxValSugar);
	return res;
}
int CoffeeMachine::AddMilk(int add) {
	int res = Add(add, m_curMilk, m_maxLevelmilk);
	return res;
}
int CoffeeMachine::AddCoffee(int add) {
	int res = Add(add, m_curValCoffee, m_maxValCoffee);
	return res;
}

CoffeeMachine::~CoffeeMachine()
{
	
	
}