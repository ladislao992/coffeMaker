#pragma once
#include<iostream>
class ICoffeeMachineRecipe
{
public:
	virtual void SetEspressoRecipe()=0;
	virtual void SetAmericanoRecipe()=0;
	virtual void SetLatteRecipe()=0;
	//virtual ~ICoffeeMachineRecipe();
	//virtual void SetNewRecipe(std::string mane, int water, int sugar, int milk, int coffee, int t, int time)=0;
	//CoffeeMachineRecipe::recipe& GetRecipe(std::string)const;
private:
};

