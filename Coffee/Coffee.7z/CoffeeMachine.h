#pragma once
#include "ICoffeeMachine.h"
#include"CoffeeMachineRecipe.h"


class CoffeeMachine : public ICoffeeMachine
{
public:
	CoffeeMachine(int water, int sugar, int milk, int coffee);
	bool MakeDrink(CoffeeMachineRecipe::recipe curRecipe) override;
	bool ChekIngredientLowLvl(int, int, int, int)override;
	int AddWater(int)override;
	int AddSugar(int)override;
	int AddMilk(int)override;
	int AddCoffee(int)override;
	~CoffeeMachine()override;
private:
	//ingredients
	int m_curWater;
	int m_curSugar;
	int m_curMilk;
	int m_curValCoffee;
	//water lvl
	int m_minLevelWater = 0;
	int m_lowLevelWater = 150;
	int m_maxLevelWater = 1000;
	//sugar lvl
	int m_minValSugar = 0;
	int m_lowValSugar = 100;
	int m_maxValSugar = 800;

	//milk lvl
	int m_minLevelmilk = 0;
	int m_maxLevelmilk = 300;
	//coffee lvl
	int m_minValCoffee = 0;
	int m_maxValCoffee = 500;
};


