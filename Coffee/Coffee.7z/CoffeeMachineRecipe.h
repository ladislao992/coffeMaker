#pragma once
#include "ICoffeeMachineRecipe.h"
#include <iostream>
#include<vector>
class CoffeeMachineRecipe : public ICoffeeMachineRecipe
{public:
	struct recipe {
		std::string name;
		int water = 0;//ml
		int sugar = 0;//mg
		int milk = 0;//ml
		int coffee = 0;//mg
		int t = 0;// water themperature
		int time = 0;//sec.

	};
	CoffeeMachineRecipe();
	//~CoffeeMachineRecipe() override;
	void SetEspressoRecipe() override;
	void SetAmericanoRecipe() override;
	void SetLatteRecipe() override;

	//void SetNewRecipe(std::string mane,int water, int sugar, int milk, int coffee, int t, int time)override;
		recipe GetRecipe(std::string)const;
private:
	recipe m_espresoo ;
	recipe m_americano;
	recipe m_latte;
	//recipe m_manualRec0;
	//recipe m_manualRec1;
	//recipe m_manualRec2;
	//recipe m_manualRec3;
	//recipe m_manualRec4;
	//recipe m_manualRec5;
	
	std::vector<recipe> m_Recipes;
};