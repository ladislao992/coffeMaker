#include <iostream>
#include"CoffeeMachine.h"
#include"CoffeeMachineRecipe.h"

int main()
{
    CoffeeMachineRecipe Recipes;

    //Recipes.SetNewRecipe("Cold americano", 80,0,0,8,45,60 );
    CoffeeMachineRecipe::recipe espresso= Recipes.GetRecipe("Espresso");
    CoffeeMachineRecipe::recipe americano= Recipes.GetRecipe("Americano");
    CoffeeMachineRecipe::recipe latte= Recipes.GetRecipe("Latte");
    
    //enter start val of ingredients:water,sugar,milk,coffee
    CoffeeMachine Redmond(1000, 800, 300, 400);
    Redmond.MakeDrink(espresso);
    Redmond.MakeDrink(americano);
    Redmond.MakeDrink(latte);
    Redmond.AddCoffee(300);
    std::cout << "Hello World!\n";
}