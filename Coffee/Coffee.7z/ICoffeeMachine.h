#pragma once
#include"CoffeeMachineRecipe.h"
class ICoffeeMachine
{
public:	
	virtual bool MakeDrink(CoffeeMachineRecipe::recipe curRecipe) = 0;
	virtual bool ChekIngredientLowLvl(int, int, int, int)= 0;
	virtual int AddWater(int)= 0;
	virtual int AddSugar(int)= 0;
	virtual int AddMilk(int)= 0;
	virtual int AddCoffee(int)= 0;
	virtual ~ICoffeeMachine();
};