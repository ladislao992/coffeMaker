#include "CoffeeMachineRecipe.h"


CoffeeMachineRecipe::CoffeeMachineRecipe() {
	m_Recipes.push_back(m_espresoo);
	m_Recipes.push_back(m_americano);
	m_Recipes.push_back(m_latte);

	SetEspressoRecipe();
	SetAmericanoRecipe();
	SetLatteRecipe();
}

void CoffeeMachineRecipe::SetEspressoRecipe() {

	m_espresoo.name = "Espresso";
	m_espresoo.water = 40;
	m_espresoo.coffee = 8;
	m_espresoo.t = 95;
	m_espresoo.time = 25;
}

void CoffeeMachineRecipe::SetAmericanoRecipe() {
	m_americano.name = "Americano";
	m_americano.water = 80;
	m_americano.coffee = m_espresoo.coffee;
	m_americano.t = m_espresoo.t;
	m_americano.time = 40;
}



void CoffeeMachineRecipe::SetLatteRecipe() {
	m_latte.name = "Latte";
	m_latte.water = m_americano.water;
	m_latte.coffee = m_espresoo.coffee * 2;
	m_latte.t = m_espresoo.t;
	m_latte.time = 40;
	m_latte.milk = 15;

}
//void CoffeeMachineRecipe::SetNewRecipe(std::string name, int water, int sugar, int milk, int coffee, int t, int time) {
//	m_Recipes.push_back(m_manualRec0);
//	m_Recipes[0]->name = name;
//	m_Recipes[0]->water = water;
//	m_Recipes[0]->coffee = coffee;
//	m_Recipes[0]->t = t;
//	m_Recipes[0]->time = time;
//	m_Recipes[0]->milk = milk;
//}
CoffeeMachineRecipe::recipe CoffeeMachineRecipe::GetRecipe(std::string name)const {
	for (int i = 0; i < m_Recipes.size(); ++i) {
		if (m_Recipes[i].name == name) {
			return m_Recipes[i];
		}
	}
}
CoffeeMachineRecipe::~CoffeeMachineRecipe() {
	
	
	//	for (int i = m_Recipes.size(); i >= 0; --i) {
	//
	//	delete m_Recipes[i];
	//}
}
